﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class gameManager : MonoBehaviour {

	public static gameManager instance = null;
	public static KeyCode[] gameCtrls;
	public static GameObject[] playerCars;
	public static GameObject[] visualCars;
	public static bool twoplayers = false;
	public static int totaldrivers = 6;

	void Awake() {
		DontDestroyOnLoad (gameObject);
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (gameObject);
		}
	}

	void Start(){
		gameCtrls = new KeyCode[2];
		playerCars = new GameObject[totaldrivers];
		visualCars = new GameObject[totaldrivers];
		gameCtrls [0] = KeyCode.LeftShift;
		gameCtrls [1] = KeyCode.RightShift;
	}
}
