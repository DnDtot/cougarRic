﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class playerSpawn : MonoBehaviour {

	public int plyerNum;
	public int randium;
	public GameObject playerCar;
	public GameObject toBeCar;
	public GameObject[] aiCar;

	void Start(){
		aiCar = Resources.LoadAll <GameObject> ("AICars");
		if (((gameManager.playerCars [plyerNum - 1] != null) && (plyerNum != 2)) || ((plyerNum == 2) && (gameManager.twoplayers == true))) {
			playerCar = gameManager.playerCars [plyerNum - 1];
			toBeCar = Instantiate (playerCar, transform.position, transform.rotation) as GameObject;
			toBeCar.GetComponent<PlayerCtrler> ().playerNum = plyerNum;
		} else if (plyerNum <= gameManager.totaldrivers) {
			randium = Random.Range (0, aiCar.Length);
			toBeCar = Instantiate (aiCar [randium], transform.position, transform.rotation) as GameObject;
		}
		Destroy (gameObject);
	}
}
