﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class carSelect : MonoBehaviour {

	public int playahNumbah;

	public Text whoSelects;
	public Text pressToPlay;

	public Button pOneSelects;
	public Button pTwoSelects;
	public Button nextButton;
	public Button[] carButtons;

	public GameObject carViewOne;
	public GameObject carViewTwo;
	public GameObject[] playahCars;
	public GameObject[] visuahCars;

	void Start(){
		playahCars = Resources.LoadAll <GameObject> ("PlayerCars");
		visuahCars = Resources.LoadAll <GameObject> ("EmptyCars");
		pressToPlay.text = "Press " + gameManager.gameCtrls [1] + " to join";
		gameManager.twoplayers = false;
	}

	void Update (){
		if (Input.GetKeyDown (gameManager.gameCtrls [1])) {
			pressToPlay.enabled = !pressToPlay.enabled;
			carViewTwo.SetActive (!carViewTwo.activeSelf);
			pTwoSelects.interactable = !pTwoSelects.interactable;
			gameManager.twoplayers = !gameManager.twoplayers;
			carViewTwo.GetComponent<carViewer> ().resetVisual ();
		}
		CheckForSelected ();
	}

	public void carPicked(int carNumbah){
		gameManager.playerCars [playahNumbah - 1] = playahCars [carNumbah];
		gameManager.visualCars [playahNumbah - 1] = visuahCars [carNumbah];
		switch (playahNumbah) {
		case (1):
			carViewOne.GetComponent<carViewer> ().resetVisual ();
			break;
		case(2):
			carViewTwo.GetComponent<carViewer> ().resetVisual ();
			break;
		}
	}

	public void setWhoSelects(int whoisit){
		playahNumbah = whoisit;
		whoSelects.text = "Select your vehicle: Player " + whoisit;
		switch (playahNumbah) {
		case (1):
			pOneSelects.image.color = Color.cyan;
			pTwoSelects.image.color = Color.white;
			break;
		case (2):
			pOneSelects.image.color = Color.white;
			pTwoSelects.image.color = Color.red;
			break;
		}
	}

	public void CheckForSelected(){
		if ((pressToPlay.enabled == true) && (carViewOne.GetComponent<carViewer> ().mahCar != null)) {
			nextButton.interactable = true;
		} else if (carViewTwo.GetComponent<carViewer> ().mahCar == null) {
			nextButton.interactable = false;
		} else if (carViewOne.GetComponent<carViewer> ().mahCar != null){
			nextButton.interactable = true;
		}
	}
}
