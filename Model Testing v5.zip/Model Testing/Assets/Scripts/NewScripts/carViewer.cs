﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class carViewer : MonoBehaviour {

	public int whichPlayer;
	public GameObject mahCar;
	public GameObject curCar;

	void Update (){
		if (transform.childCount > 0) {
			switch (whichPlayer) {
			case(1):
				mahCar.transform.Rotate (transform.up * 10 * Time.deltaTime);
				break;
			case(2):
				mahCar.transform.Rotate (-transform.up * 10 * Time.deltaTime);
				break;
			}
		}
	}

	public void resetVisual(){
		if (curCar != null) {
			Destroy (mahCar);
		}if (gameManager.visualCars [whichPlayer - 1] != null) {
			curCar = gameManager.visualCars [whichPlayer - 1];
			mahCar = Instantiate (curCar, transform.position, transform.rotation) as GameObject;
			mahCar.transform.parent = transform;
			mahCar.transform.localScale = new Vector3 (3f, 3f, 3f);
		}
	}
}
