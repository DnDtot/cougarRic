﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class CarFxs : MonoBehaviour {

	public WheelCollider[] wheelctrl;

	public float curtorq;
	public float curbrk;

	public void Drive(float torq){
		wheelctrl [2].motorTorque = torq;
		wheelctrl [3].motorTorque = torq;
		//
		curtorq = wheelctrl [2].motorTorque;
		curbrk = wheelctrl [0].brakeTorque;
		//
	}

	public void Brake(float btorq){
		wheelctrl [0].brakeTorque = btorq;
		wheelctrl [1].brakeTorque = btorq;
		wheelctrl [2].brakeTorque = btorq;
		wheelctrl [3].brakeTorque = btorq;
	}

	public void ResetBrake(){
		wheelctrl [0].brakeTorque = 0;
		wheelctrl [1].brakeTorque = 0;
		wheelctrl [2].brakeTorque = 0;
		wheelctrl [3].brakeTorque = 0;
	}

	public void Turn(float turn){
		wheelctrl [0].steerAngle = turn;
		wheelctrl [1].steerAngle = turn;
	}
}
