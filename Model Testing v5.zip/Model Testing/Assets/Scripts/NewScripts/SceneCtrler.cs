﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class SceneCtrler : MonoBehaviour {

	public void gotoscene(string sceneName){
		Time.timeScale = 1.0f;
		SceneManager.LoadScene (sceneName);
	}

	public void exitGame(){
		Debug.Log ("Doesn't work in Editor");
		Application.Quit();
	}
}
