﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class PlayerCtrler : MonoBehaviour {
	public int playerNum;

	public CarFxs Action;

	public float curtorque;
	public float curspd;
	public float maxspd;
	public float maxtorq;
	public float brktorq;
	public float maxangl;

	public bool breaking = false;
	public bool slowing = false;

	public KeyCode carBrake = KeyCode.LeftShift;

	private Rigidbody rb;
	private BoxCollider bc;

	void Start(){
		rb = GetComponent<Rigidbody> ();
		bc = GetComponent<BoxCollider> ();
		brktorq = (maxtorq / 2f);
		carBrake = gameManager.gameCtrls [playerNum - 1];
	}

	void FixedUpdate(){
		checkctrls ();
		curspd = rb.velocity.magnitude;
		anglctrl ();

		float vert = Input.GetAxis ("Vertical" + playerNum);
		float zont = Input.GetAxis ("Horizontal" + playerNum);

		Action.Turn (zont * maxangl);

		if (curspd < maxspd) {
			Action.Drive (vert * maxtorq);
			if (slowing == true) {
				Action.ResetBrake ();
				slowing = false;
			}
		} else {
			Action.Brake (brktorq);
			slowing = true;
		}
			
		if (Input.GetKey (carBrake)) {
			Action.Brake (brktorq);
			breaking = true;
		} else if (Input.GetKeyUp(carBrake)){
			Action.ResetBrake ();
			breaking = false;
		}
	}

	void anglctrl(){
		if (curspd > maxspd) {
			maxangl = 5f;
		} else if (curspd >= (maxspd * (2f / 3f))) {
			maxangl = 10f;
		} else if (curspd >= (maxspd * (1f / 3f))) {
			maxangl = 20f;
		} else {
			maxangl = 30f;
		}
	}

	void checkctrls(){
		if (gameManager.gameCtrls [playerNum - 1] != carBrake) {
			carBrake = gameManager.gameCtrls [playerNum - 1];
		}
	}
}
