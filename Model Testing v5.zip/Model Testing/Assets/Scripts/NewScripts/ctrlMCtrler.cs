﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Events;

public class ctrlMCtrler : MonoBehaviour {

	public Text CurBText;
	public Text[] ctrlText;
	public Button backButton;

	public int curNum;
	public bool checking = false;

	void Start(){
		ctrlText[0].text = "" + gameManager.gameCtrls [0];
		ctrlText[1].text = "" + gameManager.gameCtrls [1];
	}

	void OnGUI(){
		if (checking == true) {
			Event curvent = Event.current;
			if ((curvent.isKey)&&(curvent.keyCode != KeyCode.None)) {
				gameManager.gameCtrls [curNum] = curvent.keyCode;
				checkForRepeat ();
				ctrlText [curNum].text = "" + gameManager.gameCtrls [curNum];
				CurBText.text = "Change?";
				checking = false;
				checkForNone ();
			}
		}
	}

	// 0 = brake1 : 1 = brake2
	public void setButtonCtrl(int numTon){
		curNum = numTon;
		checking = true;
		switch (numTon) {
		case(0):
			CurBText.text = "Brake1";
			break;
		case(1):
			CurBText.text = "Brake2";
			break;
		}
	}

	public void checkForRepeat(){
		for (int i = 0; i < gameManager.gameCtrls.Length; i++) {
			if ((curNum != i) && (gameManager.gameCtrls[curNum] == gameManager.gameCtrls[i])) {
				gameManager.gameCtrls[curNum] = KeyCode.None;
			}
		}
	}

	public void checkForNone(){
		bool anyNone = false;
		for (int j = 0; j < gameManager.gameCtrls.Length; j++) {
			if (gameManager.gameCtrls [j] == KeyCode.None) {
				anyNone = true;
			}
		}

		if (anyNone == true) {
			backButton.interactable = false;
		} else {
			backButton.interactable = true;
		}
	}
}
