﻿using UnityEngine;
using System.Collections;

public class cameraMan : MonoBehaviour {

	public Camera mySelf;
	public GameObject myCar;
	public int myCarNum;

	void Start () {
		myCarNum = myCar.GetComponent<PlayerCtrler> ().playerNum;
		switch(myCarNum){
		case(1):
			if (gameManager.twoplayers == true) {
				mySelf.rect = new Rect (0f, 0f, .5f, 1f);
			}
			mySelf.GetComponent<AudioListener> ().enabled = true;
			break;
		case(2):
			mySelf.rect = new Rect (.5f, 0f, .5f, 1f);
			break;
		}
	}
}
