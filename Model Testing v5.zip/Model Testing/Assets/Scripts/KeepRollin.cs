﻿using UnityEngine;
using System.Collections;

//temporarily removed lines of code.
/* comments about code */

public class KeepRollin : MonoBehaviour {

	public GameObject body, fr, fl, br, bl;
	public WheelCollider frc, flc, brc, blc;

	//public float tforce = 100f;

/* public variables */
	public float maxtorque = 5000;
	public float topspeed = 50;
	public float maxturn = 30;
	public float veloc;
	public float aveloc;
	public float maxangle = 30;
	public bool braketime = false;

/* private variables */
	private float btorque;
	private float maxbtorque;
	private float minbtorque;
	private Rigidbody rb;
	private Vector3 pos;
	private Vector3 vel;
	private Quaternion rot;


	void Start () {

/* variables initialized */
		btorque = maxtorque / 2;
		maxbtorque = maxtorque * 20;
		minbtorque = btorque;
		rb = GetComponent<Rigidbody> ();
		pos = transform.position;
		rot = transform.rotation;
		vel = rb.velocity;
		rb.centerOfMass = new Vector3 (0, -1, 0);

	}
	
/* fixed update for physics engine, do not use Time.deltaTime */
	void FixedUpdate () {

/* turns directions into percents */
		float ctorque = maxtorque * Input.GetAxis ("Vertical");
		float cturn = maxturn * Input.GetAxis ("Horizontal");

/* retrieves current velocity and rotations per second */
		veloc = rb.velocity.magnitude;
		aveloc = brc.rpm / 60;

		//rb.drag = veloc / tforce;

/* checks to see if vehicle needs to slow down due to top speed or brakes */
		if ((topspeed >= veloc)&&(!braketime)) {
			
			brc.motorTorque = ctorque;
			blc.motorTorque = ctorque;
			//br.transform.Rotate (Vector3.right * aveloc, Space.Self);
			//bl.transform.Rotate (Vector3.right * aveloc, Space.Self);

			frc.brakeTorque = 0;
			flc.brakeTorque = 0;
			brc.brakeTorque = 0;
			blc.brakeTorque = 0;

		} else {

			brc.motorTorque = 0;
			blc.motorTorque = 0;
			frc.brakeTorque = btorque;
			flc.brakeTorque = btorque;
			brc.brakeTorque = btorque;
			blc.brakeTorque = btorque;

		}

		frc.steerAngle = cturn;
		flc.steerAngle = cturn;

/* adjusts btorque based on whether top speed or brakes initialize it */
		if (Input.GetKey (KeyCode.LeftShift)) {

			if (btorque < maxbtorque) {

				btorque *= 20;

			}
			braketime = true;

		} else {

			if (btorque > minbtorque) {
				
				btorque /= 20;

			}
			braketime = false;

		}

/* resets car to last reset point */
		if (Input.GetKeyDown ("r")) {

			transform.position = pos;
			transform.rotation = rot;
			rb.velocity = vel;
			brc.motorTorque = 0;
			blc.motorTorque = 0;

		}
/* checks forward */
		if(Physics.Raycast(new Vector3 (transform.position.x, 2, transform.position.z), transform.forward, 10f)){

			Debug.DrawRay(new Vector3 (transform.position.x, 2, transform.position.z), transform.forward * 10f, Color.white, 1f);

		}
	}

	void OnTriggerEnter(Collider otherobj){

/* sets new reset point when collided */
		if (otherobj.gameObject.tag == "Checkpoint"){
			
			Debug.Log ("CHECKPOINT!");
			pos = new Vector3 (transform.position.x, 0, transform.position.z);
			//Destroy (otherobj.gameObject);

		}

/* boosts vehicle when speed boost is hit */
		if (otherobj.gameObject.tag == "Speedboost") {

			Debug.Log ("FASTER!");
			rb.AddForce (Vector3.forward * 500000);
			
		}
	}
}