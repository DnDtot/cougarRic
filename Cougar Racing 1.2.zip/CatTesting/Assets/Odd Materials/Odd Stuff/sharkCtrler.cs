﻿using UnityEngine;
using System.Collections;

public class sharkCtrler : MonoBehaviour {

	public GameObject[] victims;
	public int victim = 10;
	public float swimspeed = 10;
	public GameObject track;
	public float attdist = 250;

	private Vector3 reset;

	void Start(){
		victims = GameObject.FindGameObjectsWithTag ("Car");
		reset = transform.position;
	}

	void Update(){
		if (victim > victims.Length) {
			for (int i = 0; i < (victims.Length); i++) {
				float distance = Vector3.Distance (victims [i].transform.position, track.transform.position);
				if (distance > attdist) {
					victim = i;
				}
			}
		} else {
			SharkAction ();
			float distance = Vector3.Distance (victims [victim].transform.position, track.transform.position);
			if (distance < attdist) {
				victim = 10;
				transform.position = reset;
			}
		}
	}

	void SharkAction(){
		transform.LookAt (victims [victim].transform.position);
		transform.position = Vector3.MoveTowards (transform.position, victims [victim].transform.position, swimspeed);
	}

	void OnCollisionEnter(Collision other){
		if (other.gameObject.tag == "Car") {
			playerCtrler pc = victims [victim].GetComponent<playerCtrler> ();
			victims[victim].GetComponent<Rigidbody>().velocity = Vector3.zero;
			victims[victim].transform.position = pc.respawnpt;
			victims[victim].transform.rotation = pc.respawnrt;
		}
	}
}
