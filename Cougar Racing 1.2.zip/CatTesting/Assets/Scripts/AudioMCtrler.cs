﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.Audio;
using UnityEngine.UI;

public class AudioMCtrler : MonoBehaviour {

	public AudioMixer mainMixer;
	public Slider musicSlider;
	public Slider sfxSlider;
	public float curMusicVol;
	public float curSfxVol;

	// Use this for initialization
	void Start () {
		mainMixer.GetFloat ("musicVol", out curMusicVol);
		musicSlider.value = curMusicVol;
		mainMixer.GetFloat ("sfxVol", out curSfxVol);
		sfxSlider.value = curSfxVol;
	}
	
	public void ChangeMusicVol(float mVol){
		mainMixer.SetFloat ("musicVol", mVol);
	}

	public void ChangeSFXVol(float sVol){
		mainMixer.SetFloat ("sfxVol", sVol);
	}
}
