﻿using UnityEngine;
using System.Collections;

public class swayCtrler : MonoBehaviour {

	public GameObject carBody;
	public GameObject actlwheel;
	public GameObject actrwheel;
	public WheelCollider leftwheel;
	public WheelCollider rightwheel;
	public float correcter = 20000f;
	public float lwheeldis;
	public float rwheeldis;
	public float applyforce;
	private bool hitting;
	private WheelHit wh;
	private Rigidbody rb;

	void Start(){
		rb = carBody.GetComponent<Rigidbody> ();
	}

	void Update(){
		hitting = leftwheel.GetGroundHit (out wh);
		if (hitting == true) {
			lwheeldis = (-leftwheel.transform.InverseTransformPoint (wh.point).y - leftwheel.radius) / leftwheel.suspensionDistance;
		} else {
			lwheeldis = 1;
		}
		if ((wh.point.y + leftwheel.radius >= leftwheel.suspensionDistance) && (wh.point.y + leftwheel.radius <= 0f)) {
			actlwheel.transform.position = new Vector3 (actlwheel.transform.position.x, wh.point.y + leftwheel.radius, actlwheel.transform.position.z);
		}

		hitting = rightwheel.GetGroundHit (out wh);
		if (hitting == true) {
			rwheeldis = (-rightwheel.transform.InverseTransformPoint (wh.point).y - rightwheel.radius) / rightwheel.suspensionDistance;
		} else {
			rwheeldis = 1;
		}
		if ((wh.point.y + rightwheel.radius >= rightwheel.suspensionDistance) && (wh.point.y + rightwheel.radius <= 0f)) {
			actrwheel.transform.position = new Vector3 (actrwheel.transform.position.x, wh.point.y + rightwheel.radius, actrwheel.transform.position.z);
		}


		applyforce = (lwheeldis - rwheeldis) * correcter;

		if (leftwheel.isGrounded) {
			rb.AddForceAtPosition (- leftwheel.transform.up * applyforce, leftwheel.transform.position);
		}

		if (rightwheel.isGrounded) {
			rb.AddForceAtPosition (rightwheel.transform.up * applyforce, rightwheel.transform.position);
						
		}
	}
}
