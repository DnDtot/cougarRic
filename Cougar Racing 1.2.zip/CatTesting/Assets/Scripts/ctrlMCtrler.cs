﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Events;

public class ctrlMCtrler : MonoBehaviour {

	public Text CurBText;
	public Text[] ctrlText;
	public Dropdown[] axees;
	public Button backButton;

	public int curNum;
	public bool checking = false;
	public bool checkctrl = false;

	void Start(){
		ctrlText[0].text = "" + gameManager.gameCtrls [0];
		ctrlText[1].text = "" + gameManager.gameCtrls [1];
	}

	void OnGUI(){
		if (checking == true) {
			Event curvent = Event.current;
			if ((curvent.isKey) && (curvent.keyCode != KeyCode.None)) {
				gameManager.gameCtrls [curNum] = curvent.keyCode;
				checkForRepeat ();
				ctrlText [curNum].text = "" + gameManager.gameCtrls [curNum];
				CurBText.text = "Change?";
				checking = false;
				checkForNone ();
			}
		}
	}

	// 0 = brake1 : 1 = brake2
	public void setButtonCtrl(int numTon){
		if (checking == false) {
			curNum = numTon;
			switch (numTon) {
			case(0):
				CurBText.text = "Brake1";
				checking = true;
				break;
			case(1):
				CurBText.text = "Brake2";
				checking = true;
				break;
			}
		}
	}

	public void setAxisCtrl(int numTom){
		if (axees [0].value == axees [1].value) {
			axees [numTom - 1].value = 4;
		} else {
			gameManager.axisCtrls [numTom - 1] = axees [numTom - 1].value + 1;
		}
		checkForNone ();
	}

	public void checkForRepeat(){
		for (int i = 0; i < gameManager.gameCtrls.Length; i++) {
			if ((curNum != i) && (gameManager.gameCtrls[curNum] == gameManager.gameCtrls[i])) {
				gameManager.gameCtrls[curNum] = KeyCode.None;
			}
		}
	}

	public void checkForNone(){
		bool anyNone = false;
		for (int j = 0; j < gameManager.gameCtrls.Length; j++) {
			if (gameManager.gameCtrls [j] == KeyCode.None) {
				anyNone = true;
			}
		}

		if ((anyNone == true) || (axees [0].value == 4) || (axees [1].value == 4)) {
			backButton.interactable = false;
		} else {
			backButton.interactable = true;
		}
	}
}
