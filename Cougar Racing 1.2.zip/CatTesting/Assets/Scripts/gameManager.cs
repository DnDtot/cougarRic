﻿using UnityEngine;
using System.Collections;

public class gameManager : MonoBehaviour {

	public static gameManager instance = null;
	public static int[] axisCtrls;
	public static KeyCode[] gameCtrls;
	public static GameObject[] playerCars;
	public static GameObject[] visualCars;
	public static bool twoplayers = false;
	public static int totaldrivers = 6;

	void Awake() {
		DontDestroyOnLoad (gameObject);
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (gameObject);
		}
		Screen.SetResolution (Screen.width, Screen.height, true);
	}

	void Start(){
		axisCtrls = new int[2];
		gameCtrls = new KeyCode[2];
		playerCars = new GameObject[totaldrivers];
		visualCars = new GameObject[totaldrivers];
		axisCtrls [0] = 1;
		axisCtrls [1] = 2;
		gameCtrls [0] = KeyCode.LeftShift;
		gameCtrls [1] = KeyCode.RightShift;
	}
}
