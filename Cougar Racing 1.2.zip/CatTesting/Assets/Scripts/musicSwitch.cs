﻿//Programmed by David Bushta

using UnityEngine;
using System.Collections;
using UnityEngine.Audio;

public class musicSwitch : MonoBehaviour {

	public AudioClip newmusic;

	private GameObject gm;
	private AudioSource oldmusic;
//	//	//	//	//
	void Start(){
		gm = GameObject.Find ("GameManager");
		oldmusic = gm.GetComponent<AudioSource> ();
		if (oldmusic.clip != newmusic) {
			oldmusic.clip = newmusic;
			oldmusic.Play ();
		}
		Destroy (gameObject);
	}
}
