﻿using UnityEngine;
using System.Collections;

public class mapConverter : MonoBehaviour {

	public GameObject[] cars;
	public GameObject ground;
	public Canvas minimap;

	void Start(){
		cars = GameObject.FindGameObjectsWithTag ("Car");
	}
}
