﻿using UnityEngine;
using System.Collections;

public class wheelCtrler : MonoBehaviour {

	public GameObject mywheel;

	public WheelCollider wc;

//	//	//	//	//
	void Update(){
		mywheel.transform.Rotate (((wc.rpm / 60) * 360) * Time.deltaTime, 0f, 0f);
	}
//	//	//	//	//
	public void MoveWheel (float torq){
		wc.motorTorque = torq;
	}
//	//	//	//	//
	public void TurnWheel (float turn){
		wc.steerAngle = turn;
		mywheel.transform.localEulerAngles = new Vector3 (0f, turn, 0f);
	}
//	//	//	//	//
	public void BrakeWheel(float brktorq){
		wc.brakeTorque = brktorq;
	}
}
