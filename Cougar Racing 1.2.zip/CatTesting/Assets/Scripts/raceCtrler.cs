﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class raceCtrler : MonoBehaviour {

	public GameObject[] cars;
	public GameObject CheckPtHub;

	public playerCtrler pcone;
	public playerCtrler pctwo;
	private GameObject tempobj;
	public int lockplace = 0;
//	//	//	//	//
	void Start(){
		cars = GameObject.FindGameObjectsWithTag ("Car");
		if (cars.Length <= 1) {
			Destroy (gameObject);
		}
	}
//	//	//	//	//
	void Update(){
		if (lockplace != cars.Length - 1) {
			for (int i = lockplace; i < (cars.Length - 1); i++) {
				pcone = cars [i].GetComponent<playerCtrler> ();
				pctwo = cars [i + 1].GetComponent<playerCtrler> ();
				//	//	//	//	//
				if (pctwo.curlap > pcone.curlap) {
					SwitchSpot (i);
				} else if ((pctwo.curcheckpt > pcone.curcheckpt) && (pctwo.curlap == pcone.curlap)){
					SwitchSpot (i);
				} else {
					float tempone;
					float temptwo;
					if ((CheckPtHub.transform.childCount - 1) == pcone.curcheckpt) {
						tempone = Vector3.Distance (cars [i].transform.position, CheckPtHub.transform.GetChild (0).transform.position);
					} else {
						tempone = Vector3.Distance (cars [i].transform.position, CheckPtHub.transform.GetChild (pcone.curcheckpt + 1).transform.position);
					}
					if ((CheckPtHub.transform.childCount - 1) == pctwo.curcheckpt) {
						temptwo = Vector3.Distance (cars [i + 1].transform.position, CheckPtHub.transform.GetChild (0).transform.position);
					} else {
						temptwo = Vector3.Distance (cars [i + 1].transform.position, CheckPtHub.transform.GetChild (pctwo.curcheckpt + 1).transform.position);
					}
					if ((temptwo < tempone) && (pctwo.curlap == pcone.curlap) && (pctwo.curcheckpt == pcone.curcheckpt)){
						SwitchSpot (i);
					}
				}
				CheckPlayers ();
			}
		} else {
			SceneCtrler.scripttoscene ("MainMenu");
		} 
	}
//	//	//	//	//
	void SwitchSpot(int aye){
		tempobj = cars [aye + 1];
		cars [aye + 1] = cars [aye];
		cars [aye] = tempobj;
		pcone.curplace = aye + 2;
		pctwo.curplace = aye + 1;
	}

	void CheckPlayers(){
		if (pcone.curlap > 3) {
			lockplace++;
			pcone.enabled = false;
		}
	}
}
