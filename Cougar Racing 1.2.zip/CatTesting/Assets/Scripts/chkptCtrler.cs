﻿using UnityEngine;
using System.Collections;

public class chkptCtrler : MonoBehaviour {

	void Start(){
		for (int i = 0; i < transform.childCount; i++) {
			if (i == (transform.childCount - 1)) {
				transform.GetChild(i).transform.LookAt(transform.GetChild(0).transform.position);
			} else {
				transform.GetChild(i).transform.LookAt(transform.GetChild(i + 1).transform.position);
			}
		}
		Destroy(this);
	}
}
