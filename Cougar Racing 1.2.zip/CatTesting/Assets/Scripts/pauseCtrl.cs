﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class pauseCtrl : MonoBehaviour {

	public Canvas pauseScrn;
	public Canvas optionScrn;
	public GameObject optionCtrl;

	public bool pausing = false;
	public bool deciding = false;

	void Update () {
	
		if ((Input.GetKeyDown (KeyCode.Escape)) && (deciding == false)) {
			if (pausing == true) {
				pauseScrn.enabled = false;
				Time.timeScale = 1.0f;
				pausing = false;
			} else {
				pauseScrn.enabled = true;
				Time.timeScale = 0.0f;
				pausing = true;
			}
		}
	}

	public void resumeButton(){
		pauseScrn.enabled = false;
		Time.timeScale = 1.0f;
		pausing = false;
	}

	public void optionMenu(bool scrnSwitch){
		if (scrnSwitch == true) {
			deciding = true;
			pauseScrn.enabled = false;
			optionScrn.enabled = true;
			optionCtrl.SetActive (true);
		} else {
			deciding = false;
			optionScrn.enabled = false;
			pauseScrn.enabled = true;
			optionCtrl.SetActive (false);
		}
	}
}
