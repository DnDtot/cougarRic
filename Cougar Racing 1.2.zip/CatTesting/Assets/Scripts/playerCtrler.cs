﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class playerCtrler : MonoBehaviour {

	public int playernum;
	public int curplace = 0;
	public int curlap = 1;
	public int curcheckpt = 0;

	public GameObject centermass;
	public wheelCtrler[] wheels;

	public Vector3 respawnpt;
	public Quaternion respawnrt;

	public Text speedtext;
	public Text postext;
	public Text laptext;

	public float curspeed = 0f;
	public float maxtorque = 4000f;
	public float slowrate = 10f;
	public float maxspeed = 20f;
	public float maxangle = 30f;

	public bool braking = false;
	public bool handbrake = false;
	public bool slowing = false;

	private Rigidbody rb;
	private KeyCode brakekey = KeyCode.LeftShift;
	private int axisCtrl = 1;
//	//	//	//	//
	void Start(){
		rb = GetComponent<Rigidbody> ();
		rb.centerOfMass = centermass.transform.localPosition;
		respawnpt = transform.position;
		respawnrt = transform.rotation;
		brakekey = gameManager.gameCtrls [playernum - 1];
		axisCtrl = gameManager.axisCtrls [playernum - 1];
	}
//	//	//	//	//		
	void FixedUpdate(){
		ResetControls ();
		curspeed = rb.velocity.magnitude;
			speedtext.text = "" + Mathf.Floor(curspeed) + "m/s";
		postext.text = "Place:" + curplace;
		laptext.text = "Lap:" + curlap;

		float torque = Input.GetAxis ("Vertical" + axisCtrl);
		float turnangle = Input.GetAxis ("Horizontal" + axisCtrl);

		wheels [0].TurnWheel (turnangle * maxangle);
		wheels [1].TurnWheel (turnangle * maxangle);

		if ((curspeed < maxspeed) && (torque != 0f)){
			wheels [2].MoveWheel (torque * maxtorque);
			wheels [3].MoveWheel (torque * maxtorque);
			if (slowing == true) {
				slowing = false;
				DemBrakes (0f);
			}
		} else {
			slowing = true;
			DemBrakes (slowrate * maxtorque);
		}

		if (Input.GetKey (brakekey)) {
			braking = true;
			DemBrakes (slowrate * maxtorque);
		} else if (braking == true) {
			braking = false;
			DemBrakes (0f);
		}

		if (Input.GetKeyDown (KeyCode.R)) {
			rb.velocity = Vector3.zero;
			transform.position = respawnpt;
			transform.rotation = respawnrt;
		}
	}
//	//	//	//	//
	void OnTriggerEnter(Collider other){
		if (other.tag == "Checkpoint") {
			if (other.transform.GetSiblingIndex () == (curcheckpt + 1)) {
				curcheckpt = other.transform.GetSiblingIndex ();
				respawnpt = other.transform.position;
				respawnrt = other.transform.rotation;
			} else if (((other.transform.parent.childCount - 1) == curcheckpt) && (other.transform.GetSiblingIndex() == 0)) {
				curcheckpt = 0;
				curlap++;
				respawnpt = other.transform.position;
				respawnrt = other.transform.rotation;
			}
		}
	}
//	//	//	//	//
	void DemBrakes(float yesdem){
		wheels [0].BrakeWheel (yesdem);
		wheels [1].BrakeWheel (yesdem);
		wheels [2].BrakeWheel (yesdem);
		wheels [3].BrakeWheel (yesdem);
	}
//	//	//	//	//
	void ResetControls(){
		brakekey = gameManager.gameCtrls [playernum - 1];
		axisCtrl = gameManager.axisCtrls [playernum - 1];
	}
}
