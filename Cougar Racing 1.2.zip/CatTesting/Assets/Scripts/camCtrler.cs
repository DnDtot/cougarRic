﻿using UnityEngine;
using System.Collections;

public class camCtrler : MonoBehaviour {

	public GameObject targetcar;
	public GameObject mountedhinge;
	public Camera mountedcam;
	public Canvas Huddy;
	public float fovchange = 30f;
	public float speedratio;

	private float curspeed;
	private float maxspeed;
	private Vector3 quatertemp;
	private playerCtrler pc;

	public int myCarNum;

	void Start(){
		pc = targetcar.GetComponent<playerCtrler> ();
		maxspeed = pc.maxspeed;
		transform.parent = null;
		myCarNum = targetcar.GetComponent<playerCtrler> ().playernum;
		switch(myCarNum){
		case(1):
			if (gameManager.twoplayers == true) {
				mountedcam.rect = new Rect (0f, 0f, .5f, 1f);
			}
			break;
		case(2):
			if (gameManager.twoplayers == true) {
				mountedcam.rect = new Rect (.5f, 0f, .5f, 1f);
				mountedcam.GetComponent<AudioListener> ().enabled = false;
			} else {
				Huddy.enabled = false;
				Destroy (gameObject);
			}
			break;
		default:
			Huddy.enabled = false;
			Destroy (gameObject);
			break;
		}
	}

	void Update(){
		FOVControl ();
		transform.position = targetcar.transform.position;
		quatertemp = targetcar.transform.eulerAngles;
		transform.rotation = Quaternion.Euler (0f, quatertemp.y, 0f);
	}

	void FOVControl(){
		curspeed = pc.curspeed;
		speedratio = curspeed / maxspeed;
		if (speedratio > 1) {
			speedratio = 1;
		}
		mountedcam.fieldOfView = 60 + speedratio * fovchange;
	}
}
