﻿//Scripted by David Bushta

using UnityEngine;
using System.Collections;

public class optionMCtrl : MonoBehaviour {

	public Canvas[] optMenus;
	// 0 = Options : 1 = Controls : 2 = Audio
	public GameObject ctrlCtrler;
	public GameObject audioCtrler;

	public void toMenuNum(int menuNum){
		for (int i = 0; i < optMenus.Length; i++) {
			if (i == menuNum) {
				optMenus [i].enabled = true;
				setControllers (i);
			} else {
				optMenus [i].enabled = false;
			}
		}
	}

	public void setControllers(int num){
		if (num == 1) {
			ctrlCtrler.SetActive (true);
		} else {
			ctrlCtrler.SetActive (false);
		}
		if (num == 2) {
			audioCtrler.SetActive (true);
		} else {
			audioCtrler.SetActive (false);
		}
	}
}
