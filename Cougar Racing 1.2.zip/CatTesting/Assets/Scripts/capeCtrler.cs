﻿using UnityEngine;
using System.Collections;

public class capeCtrler : MonoBehaviour {

	public GameObject mycar;
	public float speedratio;
	public Animator capeanimout;
	public Animator capeanimin;

	private float carmaxspeed;
	private Vector3 velvector;
	private Quaternion direction;
	private Rigidbody carrb;
	private playerCtrler pc;

	void Start(){
		carrb = mycar.GetComponent<Rigidbody> ();
		pc = mycar.GetComponent<playerCtrler> ();
		carmaxspeed = pc.maxspeed;
	}

	void Update(){
		velvector = carrb.velocity.normalized;
		speedratio = (pc.curspeed / carmaxspeed);
		if (speedratio > 1) {
			speedratio = 1;
		}
		capeanimout.SetFloat ("Speed", speedratio);
		capeanimin.SetFloat ("Speed", speedratio);
		if (carrb.velocity.magnitude > 1) {
			direction = Quaternion.LookRotation (velvector, Vector3.up);
			transform.rotation = Quaternion.RotateTowards (transform.rotation, direction, 5f);
		}
	}
}
